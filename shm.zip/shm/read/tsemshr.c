#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <stdio.h> 
#include <sys/sem.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define ITER 10

void affiche(int num)
{ 
	key_t shm_key = ftok("shmfile",65); 
	int shmid = shmget(shm_key,1024,0666); 
	char *str = (char*) shmat(shmid,(void*)0,0);
	printf("Data read from memory: %s\n",str);
	shmdt(str);
}
int main() 
{ 
  // ftok to generate unique key 
  
  int i=1;
  signal(SIGALRM, affiche);
  //
	//pid_t pid1;
  //
  
  // shmget returns an identifier in shmid 
  //int shmid = shmget(shm_key,1024,0666); 

  // shmat to attach to shared memory
  //char *str = (char*) shmat(shmid,(void*)0,0);
  for(i=1; i <= 10; i++)
  {
			
			alarm(4);

			pause();
			
	}
  
  /*while(1)
	{
			
			alarm(4);
			i++;
			if(i==10)
				break;
			pause();
			
	}*/
   
  
  //for(i=0; i < ITER; i++){
	
      
  //}
  //detach from shared memory 
	//shmdt(str); 
	
  // destroy the shared memory 
  //shmctl(shmid,IPC_RMID,NULL); 
	
  return 0; 
} 

